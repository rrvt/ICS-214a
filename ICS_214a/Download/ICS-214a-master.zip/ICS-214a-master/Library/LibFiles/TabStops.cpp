// Tab Stops Dummy
// Copyright Software Design & Engineering, Robert R. Van Tuyl, 2013.  All rights reserved.


#include "stdafx.h"
#include "TabStops.h"


TabStops tabStops;

