// Tab Stops Dummy
// Copyright Software Design & Engineering, Robert R. Van Tuyl, 2013.  All rights reserved.

#pragma once
#include "EditBoxes.h"


class TabStops {

public:
  
  TabStops() {}
 ~TabStops() {}

  EditBoxX* getRover() {static EditBoxX x; return &x;}  
  };


extern TabStops tabStops;
