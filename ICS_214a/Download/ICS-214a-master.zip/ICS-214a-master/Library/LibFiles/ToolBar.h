// Tool Bar to be used with Button and ComboBox


#pragma once


class ToolBar : public CToolBar {
public:
CFont font;

  ToolBar() {getFont();}
  void getFont();
  };

