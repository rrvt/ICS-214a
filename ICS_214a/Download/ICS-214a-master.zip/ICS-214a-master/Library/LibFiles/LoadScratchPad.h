// Load Scratch Pad


#pragma once


bool loadScratchPad(String& s);
