// Get String containing a GUID


#pragma once


bool getGuid(String& guid);
