// MapTable
// Copyright Software Design & Engineering, Robert R. Van Tuyl, 2013.  All rights reserved.


#include "stdafx.h"
#include "MapTable.h"


MapRecord::~MapRecord() {}
