// Win2000 to_string replacement
// BobK6RWY


#pragma once
using namespace std;


string to_string(int                Val);
string to_string(unsigned int       Val);
string to_string(long               Val);
string to_string(unsigned long      Val);
string to_string(long long          Val);
string to_string(unsigned long long Val);
string to_string(float              Val);
string to_string(double             Val);
string to_string(long double        Val);

