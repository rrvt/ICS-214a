//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ICS_214a.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   101
#define IDD_ActvtyName                  102
#define IDD_EventLogEntry               104
#define IDD_StopEntry                   105
#define IDD_EditEntry                   106
#define IDC_NameVer                     200
#define IDC_Copyright                   201
#define IDC_CompanyName                 202
#define IDC_IncidentName                203
#define IDC_PrepDate                    206
#define IDC_PrepTime                    207
#define IDC_LeaderName                  208
#define IDC_LeaderPosition              209
#define IDC_OperationPeriod             210
#define IDC_PreparedBy                  211
#define IDC_EDIT9                       212
#define IDC_MissionNumber               212
#define IDC_LogDate                     213
#define IDC_StartTime                   214
#define IDC_EndTime                     215
#define IDC_EDIT4                       216
#define IDC_LogActivity                 216
#define IDC_EntryDesc                   217
#define IDC_StopDate                    218
#define IDC_EDIT2                       219
#define IDC_StopTime                    219
#define IDC_EDIT1                       220
#define IDC_EndDate                     220
#define IDC_Ugly                        221
#define ID_Help                         400
#define ID_EditHeader                   401
#define ID_LogEntry                     402
#define ID_StopEntry                    403
#define ID_EditLogEntry                 404
#define ID_NewLog                       405
#define ID_MakeExcelFile                406

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         407
#define _APS_NEXT_CONTROL_VALUE         222
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
